# Get-Chrome80Dump
Demonstração de um Rubber Duck que captura algumas informações do navegador. 
